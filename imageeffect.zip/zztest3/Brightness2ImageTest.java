package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Brightness2ImageTest extends JFrame {

    public Brightness2ImageTest() {
        setTitle("Brightness2 image");
        add(new Brightness2Image());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                Brightness2ImageTest bi2 = new Brightness2ImageTest();
                bi2.setVisible(true);
            }
        });
    }
}