package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class ClearImageTest extends JFrame {

    public ClearImageTest() {
        setTitle("Clear image");
        add(new ClearImage());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ClearImageTest ci = new ClearImageTest();
                ci.setVisible(true);
            }
        });
    }
}