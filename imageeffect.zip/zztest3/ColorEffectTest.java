package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class ColorEffectTest extends JFrame {

    public ColorEffectTest() {
        setTitle("Color Effect");
        add(new ColorEffect());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ColorEffectTest ce = new ColorEffectTest();
                ce.setVisible(true);
            }
        });
    }
}