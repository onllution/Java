package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Clear2ImageTest extends JFrame {

    public Clear2ImageTest() {
        setTitle("Clear2 image");
        add(new Clear2Image());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                Clear2ImageTest ci2 = new Clear2ImageTest();
                ci2.setVisible(true);
            }
        });
    }
}