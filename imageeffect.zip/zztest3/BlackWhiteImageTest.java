package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BlackWhiteImageTest extends JFrame {

    public BlackWhiteImageTest() {
        setTitle("Black White image");
        add(new BlackWhiteImage());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                BlackWhiteImageTest bwi = new BlackWhiteImageTest();
                bwi.setVisible(true);
            }
        });
    }
}