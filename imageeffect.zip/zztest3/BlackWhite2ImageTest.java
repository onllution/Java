package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BlackWhite2ImageTest extends JFrame {

    public BlackWhite2ImageTest() {
        setTitle("Black White2 image");
        add(new BlackWhite2Image());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                BlackWhite2ImageTest bw2i = new BlackWhite2ImageTest();
                bw2i.setVisible(true);
            }
        });
    }
}