package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BlackWhite3ImageTest extends JFrame {

    public BlackWhite3ImageTest() {
        setTitle("Black White3 image");
        add(new BlackWhite3Image());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                BlackWhite3ImageTest bwi3 = new BlackWhite3ImageTest();
                bwi3.setVisible(true);
            }
        });
    }
}