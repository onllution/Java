package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class ColorEffect4Test extends JFrame {

    public ColorEffect4Test() {
        setTitle("Color Effect4");
        add(new ColorEffect4());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ColorEffect4Test ce4 = new ColorEffect4Test();
                ce4.setVisible(true);
            }
        });
    }
}