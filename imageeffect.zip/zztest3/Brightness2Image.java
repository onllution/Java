package zztest3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import com.sun.image.codec.jpeg.ImageFormatException;

class Brightness2Image extends JPanel {
	
    private BufferedImage mshi;
    private BufferedImage destino;
    
    public Brightness2Image() {
        loadImage();
        setSurfaceSize();
        createBrightness2Image();
    }

    private void loadImage() {
    	try{
			mshi = ImageIO.read(getClass().getResource("Big01.JPG"));
			
		}
		catch(IOException e){e.printStackTrace();}
		catch(ImageFormatException e){e.printStackTrace();}
         
    }
    
    private void createBrightness2Image() {    
    	
    	Dimension d = new Dimension();      
        d.width = mshi.getWidth(null);
        d.height = mshi.getHeight(null);
    	
    	for(int i=0; i<d.height; i++){
	         
            for(int j=0; j<d.width; j++){     
            // get the red, green and blue components of pixel at (i, j)  
            // int colorValue = mshi.getRGB(i, j);
       	    Color pixelColor = new Color(mshi.getRGB(j,i));
       	    int red =  pixelColor.getRed() ;
       	    int green =  pixelColor.getGreen() ;
      	    int blue =  pixelColor.getBlue();
       	
       	    // multiply the red, green and blue samples by 1.75 
       	    red = red <= 145? (int)(red * 1.75f): 255;
       	    green =  green <= 145 ? (int)(green * 1.75f) : 255;
       	    blue =  blue <= 145? (int)(blue * 1.75f) : 255;	
       	
       	    // update the pixel color in picture 
       	    Color newPixelColor = new Color(red, green, blue);
       	    int newRgbvalue = newPixelColor.getRGB();
       	    destino.setRGB(j, i, newRgbvalue);		          
            }//for j
         }//for i
     mshi = destino;
    }
    
    private void setSurfaceSize() {
        
        Dimension d = new Dimension();
        
        d.width = mshi.getWidth(null);
        d.height = mshi.getHeight(null);   
        
        System.out.println("Dimension image w = " + d.width + " h = " + d.height);
        
        Dimension dscr = new Dimension();
        dscr = Toolkit.getDefaultToolkit().getScreenSize();
        
        System.out.println("Dimension screen w = " + dscr.width +" h = " + dscr.height);
        
        if( (d.width >= dscr.width) || (d.height >= dscr.height) ){
        	while ( (d.width >= dscr.width) || (d.height >= dscr.height))
        	{
        	d.setSize(d.width*0.7, d.height*0.7);
        	}
        destino = ScaledImage(mshi, d.width, d.height);
    	mshi = destino;
        }
        else {destino = ScaledImage(mshi, d.width, d.height);
    	mshi = destino;}    
        setPreferredSize(d);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g; 
        g2d.drawImage(mshi, null, 0, 0);
    }
    
    private BufferedImage ScaledImage(BufferedImage srcImg, int w, int h){
        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = resizedImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, w, h, null);
        g2.dispose();
        return resizedImg;
    }  
}