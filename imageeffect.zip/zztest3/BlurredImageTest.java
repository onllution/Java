package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BlurredImageTest extends JFrame {

    public BlurredImageTest() {
        setTitle("Blurred image");
        add(new BlurredImage());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                BlurredImageTest bi = new BlurredImageTest();
                bi.setVisible(true);
            }
        });
    }
}