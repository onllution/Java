package zztest3;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class ColorEffect2Test extends JFrame {

    public ColorEffect2Test() {
        setTitle("Color Effect2");
        add(new ColorEffect2());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ColorEffect2Test ce2 = new ColorEffect2Test();
                ce2.setVisible(true);
            }
        });
    }
}