package zztest4;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class ImageIconI extends JFrame {

    public ImageIconI() {

        setTitle("ImagenIconI");
        add(new ImageIconii());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }// Constructor ImageIconI

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ImageIconI ii = new ImageIconI();
                ii.setVisible(true);
            }
        });
    }// main
    
}// Class ImageIconI

class ImageIconii extends JPanel {

    private ImageIcon imgicon;
    private ImageIcon iconimg;
    private int widthImage;
    private int heightImage;


    public ImageIconii() {

        loadImage();
        setSurfaceSize();
    }// Constructor ImageIconii

    private void loadImage() {  
    	imgicon = new ImageIcon(getClass().getResource("cycle.jpg"));	
    	
    	widthImage = imgicon.getIconWidth();
    	heightImage = imgicon.getIconHeight();  
        System.out.println("Dimension Image w = " + widthImage + " h = " + heightImage );
    }// loadImage
    
    private void setSurfaceSize() {      
        Dimension dscr = new Dimension();
        dscr = Toolkit.getDefaultToolkit().getScreenSize();    
        System.out.println("Dimension screen w = " + dscr.width +" h = " + dscr.height);
        
        if( ( widthImage >= dscr.width) || ( heightImage >= dscr.height) ){
        	do
        	{
        		widthImage = (int) (widthImage * 0.7);
        		heightImage = (int) (heightImage * 0.7);
        	}
        	while ( ( widthImage >= dscr.width) || ( heightImage >= dscr.height));
        }// if
        
        iconimg = new ImageIcon (ScaledImage(imgicon.getImage(), widthImage, heightImage));	
    	imgicon = iconimg;
        
        Dimension d = new Dimension();
        d.width = imgicon.getIconWidth();
        d.height = imgicon.getIconHeight();
        setPreferredSize(d);  
    }// setSurfaceSize

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        imgicon.paintIcon(this, g, 0, 0);  
    }// paintComponent
    
    private Image ScaledImage(Image srcImg, int w, int h){
        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = resizedImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, w, h, null);
        g2.dispose();
        return resizedImg;
    }// ScaledImage  
    
}// Class ImageIconii
