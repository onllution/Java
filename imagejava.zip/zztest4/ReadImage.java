package zztest4;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ReadImage
{	
	private static Image img;
	
	
	
    public static void main( String[] args ) throws Exception 
    {
    	final URL url = new URL("https://onllution.com/img/4017.png");
    		
    	
        try {
           
        	img = ImageIO.read(url);
        	
        } catch (IOException e) {
       	e.printStackTrace();
        }
           	
        JFrame frame = new JFrame();
        frame.setSize(300, 300);
        JLabel label = new JLabel(new ImageIcon(img));
        frame.add(label);
        frame.setVisible(true);
    }
}

