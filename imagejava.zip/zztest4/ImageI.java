package zztest4;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class ImageI extends JFrame {

    public ImageI() {

        setTitle("ImagenI");
        add(new ImageTI());
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }// Constructor ImageI

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run() {

                ImageI ie = new ImageI();
                ie.setVisible(true);
            }
        });
    }// main
}// Class ImageI

class ImageTI extends JPanel {

    private Image image;
    private ImageIcon imgicon;
    private ImageIcon iconimg;
    private int widthImage;
    private int heightImage;

    public ImageTI() {

        loadImage();
        setSurfaceSize();
    }// Construtor ImageTI

    private void loadImage() {     	
    	imgicon = new ImageIcon(getClass().getResource("imagecar.jpg"));
    	image = imgicon.getImage();	
    	
    	widthImage = imgicon.getIconWidth();
    	heightImage = imgicon.getIconHeight();  
        System.out.println("Dimension Image w = " + widthImage + " h = " + heightImage );
    }// loadImage
    
    private void setSurfaceSize() {      
        Dimension dscr = new Dimension();
        dscr = Toolkit.getDefaultToolkit().getScreenSize();    
        System.out.println("Dimension screen w = " + dscr.width +" h = " + dscr.height); 
        
        if( ( widthImage >= dscr.width) || ( heightImage >= dscr.height) ){
        	do
        	{
       		widthImage = (int) (widthImage * 0.7);
        		heightImage = (int) (heightImage * 0.7);
        	}
        	while ( ( widthImage >= dscr.width) || ( heightImage >= dscr.height));
        }// if	
        iconimg = new ImageIcon (ScaledImage(image, widthImage, heightImage));	
    	image = iconimg.getImage();
        
        
        Dimension d = new Dimension();
        d.width = image.getWidth(null);
        d.height = image.getHeight(null);
        setPreferredSize(d);  
    }// setSurfaceSize

    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;         
        g2d.drawImage(image, 0, 0, this);       
    }// paintComponent
    
    private Image ScaledImage(Image srcImg, int w, int h){
        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = resizedImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, w, h, null);
        g2.dispose();
        return resizedImg;
    }// ScaledImage  
    
}// Class ImageTI
