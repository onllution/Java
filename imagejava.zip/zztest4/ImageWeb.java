package zztest4;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ImageWeb extends JPanel{
	
	 private static BufferedImage img;
	 private static BufferedImage endimg;
	 private static int widthimg;
	 private static int heightimg;

	    public ImageWeb(URL url) throws IOException {
	    	
	        img = ImageIO.read(url);
            setSurfaceSize();
	    }// Constructor ImageWeb
	    
	    public void paintComponent(Graphics g) {
	    	Graphics2D g2d = (Graphics2D) g;
	    	g2d.drawImage(img, 0, 0, this);
	    }// paintComponent
	    
	    public void setSurfaceSize() {
	        
	        widthimg = img.getWidth();
		    heightimg = img.getHeight();
	        System.out.println("Dimension image w = " + widthimg + " h = " + heightimg);
	        
	        Dimension dscr = new Dimension();
	        dscr = Toolkit.getDefaultToolkit().getScreenSize();
	        System.out.println("Dimension screen w = " + dscr.width +" h = " + dscr.height);
	        
	        if( (widthimg >= dscr.width) || (heightimg >= dscr.height) ){
	        	do
	        	{
	        	widthimg = (int) (widthimg * 0.7);
	        	heightimg = (int) (heightimg * 0.7);
	        	}
	        	while ( (widthimg >= dscr.width) || (heightimg >= dscr.height));
	        }// if	
	        
	        endimg = ScaledImage(img, widthimg, heightimg);
	    	img = endimg;        
	    }// setSurfaceSize
	        
	    private BufferedImage ScaledImage(BufferedImage srcImg, int w, int h){
	        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
	        Graphics2D g2 = resizedImg.createGraphics();
	        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	        g2.drawImage(srcImg, 0, 0, w, h, null);
	        g2.dispose();
	        return resizedImg;
	    }// ScaledImage      
	        
	    public static void main(String[] args) throws Exception {

	    final URL lenna =
	        new URL("https://onllution.com/img/montagne.jpg");

	    ImageWeb image = new ImageWeb(lenna);

	    JFrame frame = new JFrame("ImageWeb");
	    frame.setSize(widthimg, heightimg + 20);
	    frame.add(image);
	    frame.setLocationRelativeTo(null);
	    frame.setVisible(true);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   }// main	
	    
}// Class ImageWeb
